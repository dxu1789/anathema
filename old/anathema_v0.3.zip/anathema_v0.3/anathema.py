import os
import random
import sys
import threading
import time
import winsound

def parseline(line):
    # tokens = line.split()
    # wordarray.append(tokens[0] + " " + tokens[1])
    # parsedline = line.split(":")[0] # chemistry words
    # parsedline = line.split()
    # if (parsedline != "\n"):
    #    wordarray.append(parsedline)

    return line.replace("\n", "")

def playsound():
    winsound.PlaySound("sounds\\alarm.wav", winsound.SND_FILENAME)

def playround(filename):
    print "[Opening file: %s]" % (filename)
    wordfile = open(filename)
    wordarray = []
    for line in wordfile:
        wordarray.append(parseline(line))        
    wordfile.close()

    def getword(array):
        try:
            playsound()
            print "\n\n\n\n"
            if len(array) > 0:
                # display a word
                nextindex = random.randint(0, len(array) - 1)
                print array.pop(nextindex)

                print "Press [ctrl+c] if word was guessed successfully."
                begin = time.time()
                offset = 10.0
                end = begin + offset
                while time.time() < end:
                    print str(end - time.time()), 
                    time.sleep(1)

                getword(array)
                
            else:
                print "[ROUND COMPLETE: no more words in the list]"
                return
            
        except KeyboardInterrupt:
            getword(array)
            
    getword(wordarray)
    return

wordlist_directory = "words"
filelist = os.listdir(wordlist_directory)
print "[Opening directory: %s]" % (wordlist_directory)

for i in range(len(filelist)):
    print "[%s]  %s" % (i, filelist[i])

badinput = True
filename = "words\\"
while badinput:
    try:
        filenumber = int(raw_input("Enter index of file to open: "))
        if filenumber in range(len(filelist)):
            filename += filelist[filenumber]
            badinput = False
        else:
            print "[index out of range]"
    except ValueError:
        print "[input was not a number]"


playround(filename)
raw_input("Press [enter] to quit: ")
